This directory contains useful scripts and instructions for
maintaining the ITK source code tree.  These are not intended
to be run all the time, but these little utility scripts
can be usefull as new code is being incorporated into ITK to
help configure the code into an ITK style, or ITK best practices.
