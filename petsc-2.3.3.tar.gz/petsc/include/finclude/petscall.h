!
!  Single Fortran include file for all of PETSc
!

#include "include/finclude/petsc.h"
#include "include/finclude/petscdraw.h"
#include "include/finclude/petscviewer.h"
#include "include/finclude/petscis.h"
#include "include/finclude/petscvec.h"
#include "include/finclude/petscmat.h"
#include "include/finclude/petscpc.h"
#include "include/finclude/petscksp.h"
#include "include/finclude/petscsnes.h"
#include "include/finclude/petscda.h"
