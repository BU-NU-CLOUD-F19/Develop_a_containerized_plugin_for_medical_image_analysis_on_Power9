""" This module loads all the classes from the VTK Chemistry library into
its namespace.  This is an optional module."""

from vtkChemistryPython import *
