""" This module loads all the classes from the VTK Geovis library into
its namespace.  This is an optional module."""

from vtkGeovisPython import *
